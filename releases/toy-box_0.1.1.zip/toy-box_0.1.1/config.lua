-- Checkboxes can display images without stretching them, but buttons have a left
-- click sound. I can't decide and am spending too much time on this. So for now
-- it's controllable here.

USE_CHECKBOXES = true

-- Distance player must walk for the GUI to automatically close

GUI_CLOSE_DISTANCE = 0.1 -- actually we'll keep this super small
