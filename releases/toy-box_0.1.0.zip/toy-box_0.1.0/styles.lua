data.raw["gui-style"].default["toy-box-button-style"] = {
	type = "button_style",
	parent = "button_style",
	left_click_sound = {{
		filename = "__core__/sound/gui-click.ogg",
        volume = 1
    }}
}

data.raw["gui-style"].default["toy-box-item-button-base"] = {
	type = "button_style",
	parent = "button_style",
	left_click_sound = {{
		filename = "__core__/sound/gui-click.ogg",
        volume = 1
    }}
}
