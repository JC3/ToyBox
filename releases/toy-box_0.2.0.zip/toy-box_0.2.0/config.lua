-- Checkboxes can display images without stretching them, but the minecraft look
-- is kinda cool. So it's controllable here, for now.

USE_CHECKBOXES = true

-- Distance player must walk for the GUI to automatically close

GUI_CLOSE_DISTANCE = 0.1 -- actually we'll keep this super small
