require "names"

data:extend({{
    type = "font",
    name = CATEGORY_FONT_NAME,
    from = "default-bold",
    size = 12
}})
